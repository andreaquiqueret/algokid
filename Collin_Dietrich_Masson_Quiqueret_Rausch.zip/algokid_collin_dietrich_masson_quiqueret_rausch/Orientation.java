public interface Orientation {

	public final int GAUCHE =1;
	public final int DROITE =2;
	public final int BAS = 3;
	public final int HAUT = 4;

}